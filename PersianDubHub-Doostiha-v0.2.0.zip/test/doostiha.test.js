'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const {
  parseListing,
  parsePost,
  extractVideoLinks,
  makeId,
  postUrlFromId,
  isDoostihaPostUrl
} = require('../doostiha');

const postUrl = 'https://www.doostihaa.com/post/1405/08/28/sample-movie-2026.html';

test('parses dubbed movie cards from a Doostiha category page', () => {
  const html = `
    <html><body>
      <article class="movie-card">
        <a href="${postUrl}"><img src="https://www.doostihaa.com/poster.jpg" alt="\u062F\u0627\u0646\u0644\u0648\u062F \u0641\u06CC\u0644\u0645 \u062A\u0633\u062A 2026"></a>
        <h2><a href="${postUrl}">\u062F\u0627\u0646\u0644\u0648\u062F \u0641\u06CC\u0644\u0645 \u062A\u0633\u062A 2026</a></h2>
        <span>\u062F\u0648\u0628\u0644\u0647 \u0641\u0627\u0631\u0633\u06CC</span>
      </article>
    </body></html>`;
  const records = parseListing(html, '/topics/dl-film/dubing-movies');
  assert.equal(records.length, 1);
  assert.equal(records[0].name, '\u062A\u0633\u062A 2026');
  assert.equal(records[0].poster, 'https://www.doostihaa.com/poster.jpg');
  assert.equal(records[0].releaseInfo, '2026');
  assert.equal(records[0].website, postUrl);
});

test('parses movie metadata and confirms Persian dubbing', () => {
  const html = `
    <html><head>
      <meta property="og:title" content="\u062F\u0627\u0646\u0644\u0648\u062F \u0641\u06CC\u0644\u0645 \u062A\u0633\u062A 2026">
      <meta property="og:image" content="https://www.doostihaa.com/poster.jpg">
      <meta name="description" content="\u062E\u0644\u0627\u0635\u0647 \u062F\u0627\u0633\u062A\u0627\u0646 \u0641\u06CC\u0644\u0645">
    </head><body>
      <h1>\u062F\u0627\u0646\u0644\u0648\u062F \u0641\u06CC\u0644\u0645 \u062A\u0633\u062A 2026</h1>
      <p>\u062F\u0648\u0628\u0644\u0647 \u0641\u0627\u0631\u0633\u06CC</p>
      <p>7.2/10 IMDb</p>
      <p>\u0633\u0627\u0644 \u0627\u0646\u062A\u0634\u0627\u0631: 2026</p>
      <p>\u0645\u062F\u062A \u0632\u0645\u0627\u0646: 109 \u062F\u0642\u06CC\u0642\u0647</p>
    </body></html>`;
  const meta = parsePost(html, postUrl);
  assert.equal(meta.name, '\u062A\u0633\u062A 2026');
  assert.equal(meta.poster, 'https://www.doostihaa.com/poster.jpg');
  assert.equal(meta.releaseInfo, '2026');
  assert.equal(meta.imdbRating, '7.2');
  assert.equal(meta.runtime, '109m');
  assert.equal(meta._isDubbed, true);
});

test('extracts published MP4 qualities and keeps only Doostiha video hosts', () => {
  const html = `
    <a href="https://doostihaa.upera.tv/123-1080.mp4?ref=abc">\u062F\u0627\u0646\u0644\u0648\u062F 1080p</a>
    <a href="https://doostihaa.upera.tv/123-720.mp4?ref=abc">\u062F\u0627\u0646\u0644\u0648\u062F 720p</a>
    <a href="https://example.org/not-ours-1080.mp4">external</a>`;
  const links = extractVideoLinks(html, postUrl);
  assert.equal(links.length, 2);
  assert.equal(links[0].quality, '1080p');
  assert.equal(links[1].quality, '720p');
});

test('uses a stable, validated Stremio ID for each post URL', () => {
  const id = makeId(postUrl);
  assert.equal(postUrlFromId(id), postUrl);
  assert.equal(isDoostihaPostUrl(postUrl), true);
  assert.equal(isDoostihaPostUrl('https://example.org/post/1405/08/28/x.html'), false);
  assert.equal(postUrlFromId('doostiha:not-a-valid-post'), '');
});
